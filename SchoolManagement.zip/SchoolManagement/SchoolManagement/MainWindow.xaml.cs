﻿using SchoolManagement.DataAccess.Repository;
using SchoolManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SchoolManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FirstNameSearchTextBox.Text = string.Empty;
            studentGrid.ItemsSource = GetStudentDetails(0, 10, null).ToList();
        }

        private IEnumerable<Student> GetStudentDetails(int startIndex, int numberOfRecords, string firstName)
        { 
            var _studentRepo = new StudentRepository();
            var studentData = _studentRepo.GetStudent(0, 10, firstName);
            return studentData;
        }
    }
}
