﻿using SchoolManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagement.DataAccess.IRepository
{
    public interface IStudentRepository
    {
        IEnumerable<Student> GetStudent(int startIndex = 0, int numberOfRecords = 10, string firstName = null);
    }
}
