﻿using SchoolManagement.DataAccess.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagement.DataAccess.Repository
{
    public class StudentRepository : BaseContext, IStudentRepository
    {
        public IEnumerable<Model.Student> GetStudent(int startIndex = 0, int numberOfRecords = 10, string firstName = null)
        {
            if (firstName != null)
                return DbContext.Student.Where(x => x.FirstName.Equals(firstName, StringComparison.InvariantCultureIgnoreCase));
            else
            {
                return DbContext.Student.OrderBy(x => x.StudentId).Skip(startIndex * numberOfRecords).Take(numberOfRecords);
            }
        }
    }
}
