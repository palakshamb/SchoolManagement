﻿using SchoolManagement.DataAccess.IRepository;
using SchoolManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagement.DataAccess.Repository
{
    public class StudentRepository : BaseContext, IStudentRepository
    {
        public IEnumerable<Student> GetStudent(string searchString = null, string orderByColumn = "student Id", bool orderbyDirection = true)
        {
            IEnumerable<Student> list;
            if (searchString != null)
                list = DbContext.Student.Where(x => x.FirstName.StartsWith(searchString) || x.SecondName.StartsWith(searchString));
            else
            {
                list = DbContext.Student;
            }
            switch (orderByColumn.ToLower())
            {
                case "student id":
                    if (orderbyDirection)
                        return list.OrderBy(x => x.StudentId);
                    else
                        return list.OrderByDescending(x => x.StudentId);
                case "first name":
                    if (orderbyDirection)
                        return list.OrderBy(x => x.FirstName);
                    else
                        return list.OrderByDescending(x => x.FirstName);
                case "last name":
                    if (orderbyDirection)
                        return list.OrderBy(x => x.SecondName);
                    else
                        return list.OrderByDescending(x => x.SecondName);
                case "roll number":
                    if (orderbyDirection)
                        return list.OrderBy(x => x.RollNumber);
                    else
                        return list.OrderByDescending(x => x.RollNumber);
                case "class":
                    if (orderbyDirection)
                        return list.OrderBy(x => x.Class);
                    else
                        return list.OrderByDescending(x => x.Class);
                default:
                    if (orderbyDirection)
                        return list.OrderBy(x => x.StudentId);
                    else
                        return list.OrderByDescending(x => x.StudentId);
            }
        }
    }
}
