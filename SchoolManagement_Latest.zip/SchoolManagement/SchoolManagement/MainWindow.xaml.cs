﻿using SchoolManagement.DataAccess.Repository;
using SchoolManagement.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;

namespace SchoolManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// PageIndex of the Datagrid
        /// </summary>
        int _pageIndex = 1;
        /// <summary>
        /// Number of rows to show in datagrid
        /// </summary>
        private int _numberOfRecPerPage = 5;
        private enum PagingMode { First = 1, Next = 2, Previous = 3, Last = 4, PageCountChange = 5 };
        /// <summary>
        /// List of rows binded to the datagrid
        /// </summary>
        private List<Student> _studentList;
        /// <summary>
        /// Stores previous sorted column
        /// </summary>
        private string _previousSortColumn = "";
        /// <summary>
        /// Stores previous sorted direction
        /// </summary>
        private string _priviousSortDirection = "";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SearchBox.Text = string.Empty;
            GetStudentDetails(null, ListSortDirection.Ascending, "student id");
            Navigate((int)PagingMode.First);
            this.DataContext = this;
        }

        /// <summary>
        /// Gets Student list
        /// </summary>
        /// <param name="searchString"></param>
        /// <param name="sortDirection"></param>
        /// <param name="sortColumn"></param>
        /// <returns></returns>
        private IEnumerable<Student> GetStudentDetails(string searchString, ListSortDirection sortDirection, string sortColumn)
        { 
            var _studentRepo = new StudentRepository();
            _studentList = _studentRepo.GetStudent(searchString, sortColumn, (int)sortDirection == (int)ListSortDirection.Ascending).ToList();
            return _studentList;
        }

        /// <summary>
        /// Add columns from code behind (not used)
        /// </summary>
        private void AddStudentGridColumns()
        {
            DataGridTextColumn studentId = new DataGridTextColumn();
            studentId.Header = "STUDENT ID";
            studentId.Binding = new Binding("StudentId");
            studentGrid.Columns.Add(studentId);

            DataGridTextColumn rollNumber = new DataGridTextColumn();
            rollNumber.Header = "ROLL NUMBER";
            rollNumber.Binding = new Binding("RollNumber");
            rollNumber.CanUserSort = true;
            studentGrid.Columns.Add(rollNumber);

            DataGridTextColumn firstName = new DataGridTextColumn();
            firstName.Header = "FIRST NAME";
            firstName.Binding = new Binding("FirstName");
            firstName.CanUserSort = true;
            studentGrid.Columns.Add(firstName);

            DataGridTextColumn secondName = new DataGridTextColumn();
            secondName.Header = "LAST NAME";
            secondName.Binding = new Binding("SecondName");
            secondName.CanUserSort = true;
            studentGrid.Columns.Add(secondName);

            DataGridTextColumn c = new DataGridTextColumn();
            c.Header = "CLASS";
            c.Binding = new Binding("Class");
            c.CanUserSort = true;
            studentGrid.Columns.Add(c);
        }

        /// <summary>
        /// Search students by his/her "First" or "last" name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FirstNameSearchTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            var searchBox = (TextBox)sender;
            var searchText = string.IsNullOrEmpty(searchBox.Text) ? null : searchBox.Text;
            GetStudentDetails(searchText, ListSortDirection.Ascending, "Student id");
            Navigate((int)PagingMode.First);
        }

        /// <summary>
        /// Paging "First"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFirst_Click(object sender, RoutedEventArgs e)
        {
            Navigate((int)PagingMode.First);
        }

        /// <summary>
        /// Paging "Next"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            Navigate((int)PagingMode.Next);
        }

        /// <summary>
        /// Paging "Previous"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrev_Click(object sender, RoutedEventArgs e)
        {
            Navigate((int)PagingMode.Previous);
        }

        /// <summary>
        /// Paging "Last"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLast_Click(object sender, RoutedEventArgs e)
        {
            Navigate((int)PagingMode.Last);
        }

        /// <summary>
        /// Close Details popup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CloseDetails_Click(object sender, RoutedEventArgs e)
        {
            this.detailsPopup.IsOpen = false;
        }
        
        /// <summary>
        /// Paging of datagrid
        /// </summary>
        /// <param name="mode"></param>
        private void Navigate(int mode)
        {
            int count;
            switch (mode)
            {
                case (int)PagingMode.Next:
                    btnPrev.IsEnabled = true;
                    btnFirst.IsEnabled = true;
                    if (_studentList.Count >= (_pageIndex * _numberOfRecPerPage))
                    {
                        if (_studentList.Skip(_pageIndex * _numberOfRecPerPage).Take(_numberOfRecPerPage).Count() == 0)
                        {
                            studentGrid.ItemsSource = null;
                            studentGrid.ItemsSource = _studentList.Skip((_pageIndex * _numberOfRecPerPage) - _numberOfRecPerPage).Take(_numberOfRecPerPage);
                            count = (_pageIndex * _numberOfRecPerPage) + (_studentList.Skip(_pageIndex * _numberOfRecPerPage).Take(_numberOfRecPerPage)).Count();
                        }
                        else
                        {
                            studentGrid.ItemsSource = null;
                            studentGrid.ItemsSource = _studentList.Skip(_pageIndex * _numberOfRecPerPage).Take(_numberOfRecPerPage);
                            count = (_pageIndex * _numberOfRecPerPage) + (_studentList.Skip(_pageIndex * _numberOfRecPerPage).Take(_numberOfRecPerPage)).Count();
                            _pageIndex++;
                        }

                        lblpageInformation.Content = count + " of " + _studentList.Count;
                    }
                    else
                    {
                        btnNext.IsEnabled = false;
                        btnLast.IsEnabled = false;
                    }

                    break;
                case (int)PagingMode.Previous:
                    btnNext.IsEnabled = true;
                    btnLast.IsEnabled = true;
                    if (_pageIndex > 1)
                    {
                        _pageIndex -= 1;
                        studentGrid.ItemsSource = null;
                        if (_pageIndex == 1)
                        {
                            studentGrid.ItemsSource = _studentList.Take(_numberOfRecPerPage);
                            count = _studentList.Take(_numberOfRecPerPage).Count();
                            lblpageInformation.Content = count + " of " + _studentList.Count;
                        }
                        else
                        {
                            studentGrid.ItemsSource = _studentList.Skip(_pageIndex * _numberOfRecPerPage).Take(_numberOfRecPerPage);
                            count = Math.Min(_pageIndex * _numberOfRecPerPage, _studentList.Count);
                            lblpageInformation.Content = count + " of " + _studentList.Count;
                        }
                    }
                    else
                    {
                        btnPrev.IsEnabled = false;
                        btnFirst.IsEnabled = false;
                    }
                    break;
                case (int)PagingMode.First:
                    _pageIndex = 2;
                    Navigate((int)PagingMode.Previous);
                    break;
                case (int)PagingMode.Last:
                    _pageIndex = (_studentList.Count / _numberOfRecPerPage);
                    Navigate((int)PagingMode.Next);
                    break;
            }
        }

        /// <summary>
        /// Datagrid custom sorting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void studentGrid_Sorting(object sender, DataGridSortingEventArgs e)
        {
            DataGridColumn column = e.Column;
            ListSortDirection direction;

            if (_previousSortColumn.Equals(e.Column.Header.ToString(), StringComparison.InvariantCultureIgnoreCase))
            {
                direction = _priviousSortDirection.Equals(ListSortDirection.Ascending.ToString()) ? ListSortDirection.Descending : ListSortDirection.Ascending;
            }
            else {
                direction = ListSortDirection.Ascending;
            }
            e.Handled = true;
            e.Column.SortDirection = direction;
            _previousSortColumn = e.Column.Header.ToString();
            _priviousSortDirection = direction.ToString();

            var searchText = string.IsNullOrEmpty(SearchBox.Text) ? null : SearchBox.Text;
            GetStudentDetails(searchText, direction, e.Column.Header.ToString());
            Navigate((int)PagingMode.First);
        }

        /// <summary>
        /// View student details popup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DetailsButton_Click(object sender, RoutedEventArgs e)
        {
            this.DataContext = this.studentGrid.SelectedItem;
            this.detailsPopup.IsOpen = true;
        }

        /// <summary>
        /// Datagrid selected list item change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void studentGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.DataContext = this.studentGrid.SelectedItem;
            if (this.DataContext == null)
            {
                this.detailsPopup.IsOpen = false;
                return;
            }
            this.detailsPopup.IsOpen = true;
        }
    }

    public class StudentList : ObservableCollection<Student>
    { 
    
    }
}
