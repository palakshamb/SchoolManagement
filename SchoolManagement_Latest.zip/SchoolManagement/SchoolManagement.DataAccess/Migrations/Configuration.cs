namespace SchoolManagement.DataAccess.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<SchoolManagement.DataAccess.SchoolManagementDbContex>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(SchoolManagement.DataAccess.SchoolManagementDbContex context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.

            InsertStudents();
        }

        private void InsertStudents()
        {
            var context = new SchoolManagementDbContex();
            if (context.Student.FirstOrDefault(x => x.RollNumber == 1) == null)
            {
                context.Student.Add(new Model.Student() { RollNumber = 1, FirstName = "Palaksha", SecondName = "Basavaraju", Class = Model.common.Standard.FirstStandard });
                context.Student.Add(new Model.Student() { RollNumber = 2, FirstName = "Prakyath", SecondName = "Shenoy", Class = Model.common.Standard.SecondStandard });
                context.Student.Add(new Model.Student() { RollNumber = 3, FirstName = "Shankar", SecondName = "Dokula", Class = Model.common.Standard.LKG });
                context.Student.Add(new Model.Student() { RollNumber = 4, FirstName = "Karthik", SecondName = "Shetty", Class = Model.common.Standard.UKG });
                context.Student.Add(new Model.Student() { RollNumber = 5, FirstName = "Mahesh", SecondName = "Lingappa", Class = Model.common.Standard.LKG });
                context.Student.Add(new Model.Student() { RollNumber = 6, FirstName = "Shalini", SecondName = "Anbalagan", Class = Model.common.Standard.FirstStandard });
                context.Student.Add(new Model.Student() { RollNumber = 7, FirstName = "Sathish", SecondName = "Chellasamy", Class = Model.common.Standard.FirstStandard });
                context.Student.Add(new Model.Student() { RollNumber = 8, FirstName = "Sunil", SecondName = "Yadav", Class = Model.common.Standard.SecondStandard });
                context.Student.Add(new Model.Student() { RollNumber = 9, FirstName = "Ravi", SecondName = "Gowda", Class = Model.common.Standard.FirstStandard });
                context.Student.Add(new Model.Student() { RollNumber = 10, FirstName = "Sushma", SecondName = "Gowda", Class = Model.common.Standard.SecondStandard });
                context.Student.Add(new Model.Student() { RollNumber = 11, FirstName = "Vishwa", SecondName = "Gowda", Class = Model.common.Standard.FirstStandard });
                context.SaveChanges();
            }
        }
    }
}
