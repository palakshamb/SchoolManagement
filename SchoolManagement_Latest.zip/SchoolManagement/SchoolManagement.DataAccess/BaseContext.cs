﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagement.DataAccess
{
    public class BaseContext
    {
        private SchoolManagement.DataAccess.SchoolManagementDbContex _dbContext;
        public BaseContext()
        {
            _dbContext = new SchoolManagementDbContex();
        }
        protected SchoolManagementDbContex DbContext { get { return _dbContext; } }
    }
}
