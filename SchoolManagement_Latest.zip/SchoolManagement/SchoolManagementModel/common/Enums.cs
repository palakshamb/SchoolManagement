﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagement.Model.common
{
    public class Enums
    {
        
    }

    public enum Standard
    {
        LKG = 0,
        UKG,
        FirstStandard,
        SecondStandard
    }
}
