﻿using CricketTournament.Business;
using CricketTournament.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CricketTournament.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Bucket> buckets = new List<Bucket>();
            //var q1 = new Bucket("Q1", false, TournamentEnums.BucketType.Qualifier, 1, false);
            //q1.AddTeam(new Team("A"));
            //q1.AddTeam(new Team("B"));
            //var q2 = new Bucket("Q2", false, TournamentEnums.BucketType.Qualifier, 2, false);
            //q2.AddTeam(new Team("C"));
            //q2.AddTeam(new Team("D"));
            //var q3 = new Bucket("Q3", true, TournamentEnums.BucketType.Qualifier, 3, true);
            //q3.AddTeam(new Team("E"));
            //q3.AddTeam(new Team("F"));

            //var q1 = new Bucket("Q1", false, TournamentEnums.BucketType.Qualifier, 1, true);
            //q1.AddTeam(new Team("A"));
            //q1.AddTeam(new Team("B"));
            //var q2 = new Bucket("Q2", false, TournamentEnums.BucketType.Qualifier, 2, false);
            //q2.AddTeam(new Team("C"));
            //q2.AddTeam(new Team("D"));
            //var q3 = new Bucket("Q3", false, TournamentEnums.BucketType.Qualifier, 3, false);
            //q3.AddTeam(new Team("E"));
            //q3.AddTeam(new Team("F"));

            //buckets.Add(q1);
            //buckets.Add(q2);
            //buckets.Add(q3);

            var iplPlayOff = new IPLPlayoffHelper(iplPlayOff_RecieveMessage, (bucket) => { return Console.ReadLine(); }, tournamentBuckets: buckets);
            iplPlayOff.RunTournament();

            Console.ReadLine();
        }

        static void iplPlayOff_RecieveMessage(object obj, MessageEventArguments e)
        {
            Console.WriteLine(e.Message);
            Console.WriteLine();
        }
    }
}
