﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CricketTournament.Model;
using CricketTournament.Business.IManager;
using CricketTournament.Business.Manager;

namespace CricketTournament.Business
{
    public class IPLPlayoffHelper
    {
        private ITournamentRunner IPLPlayoffRunner { get; set; }
        
        public IPLPlayoffHelper(EventHandler<MessageEventArguments> printMessage, Func<Bucket, string> matchWinnerSelector = null, List<Bucket> tournamentBuckets = null)
        {
            this.IPLPlayoffRunner = new IPLTournamentRunner(matchWinnerSelector, tournamentBuckets);
            this.IPLPlayoffRunner.RecieveMessage += printMessage;
        }

        public void RunTournament()
        {
            IPLPlayoffRunner.RunTournament();
        }
    }
}
