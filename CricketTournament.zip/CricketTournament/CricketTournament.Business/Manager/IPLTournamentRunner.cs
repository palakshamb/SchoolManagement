﻿using CricketTournament.Business.IManager;
using CricketTournament.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CricketTournament.Business.Manager
{
    public class IPLTournamentRunner : ITournamentRunner
    {
        private Func<Bucket, string> _matchWinnnerSelector;
        private List<Bucket> _tournamentBuckets;
        private Bucket _finalBucket;

        public event EventHandler<MessageEventArguments> RecieveMessage;

        public IPLTournamentRunner(Func<Bucket, string> matchWinnerSelector, List<Bucket> tournamentBuckets)
        {
            this.MatchWinnerSelector = matchWinnerSelector;
            //this.TournamentBuckets = tournamentBuckets.OrderBy(x => x.HasPrevilageToGoFinal).ThenBy(x => x.BucketPlayOrder).ToList() ?? new List<Bucket>();
            this.TournamentBuckets = tournamentBuckets ?? new List<Bucket>();

            if (tournamentBuckets != null)
            {
                if (this.TournamentBuckets.Any(x => x.BucketType == TournamentEnums.BucketType.Final))
                    throw new ArgumentException("You have no privilate to add bucket of type Final");

                // As of now this constraint is added to avoid extra validation. This can be remove, but need to add logic to handle it.
                if (!this.TournamentBuckets.Any(x => x.HasPrevilageToGoFinal) || this.TournamentBuckets.Where(x => x.HasPrevilageToGoFinal).Count() > 1)
                    throw new ArgumentException("Atleast one bucket should have \"HasPrevilageToGoFinal\" set to true!");

                if (this.TournamentBuckets.Select(x => x.BucketPlayOrder).Distinct().Count() == this.TournamentBuckets.Count - 1)
                    throw new ArgumentException("BucketPlayOrder should be unique");

                if (this.TournamentBuckets.Any(x => x.Teams.Count != 2))
                    throw new ArgumentException("Each bucket should have 2 teams");

                //Not required
                //if (!this.TournamentBuckets.First(x => x.HasPrevilageToGoFinal).HasAnotherChance)
                //    throw new ArgumentException("Bucket with HasPrevilageToGoFinal should also have HasAnotherChance.");
            }

            ManageDefaultData();
        }

        public Func<Bucket, string> MatchWinnerSelector
        {
            get
            {
                return _matchWinnnerSelector;
            }
            set
            {
                _matchWinnnerSelector = value;
            }
        }

        public List<Bucket> TournamentBuckets
        {
            get
            {
                return _tournamentBuckets;
            }
            set
            {
                _tournamentBuckets = value;
            }
        }

        public void RunTournament()
        {
            Bucket currentMatch = GetBucketToRun();
            do
            {
                if (currentMatch.Teams.Count == 1)
                {
                    //Intermediate matches
                    var interM = GetIntermediateBuket(IsFirstMatch(currentMatch), currentMatch.BucketPlayOrder);
                    if (interM != null)
                    {
                        interM.AddTeam(currentMatch.Teams.First());
                        currentMatch.IsMatchPlayed = true;
                    }
                    else
                    {
                        GetFinalBucket().AddTeam(currentMatch.Teams.First());
                    }
                    currentMatch = interM;
                }

                SendMessage(string.Format("Current Match -> {0} v/s {1}. Whom has won?", currentMatch.Teams.First().Name, currentMatch.Teams.Last().Name));
                var winner = MatchWinnerSelector(currentMatch);

                if (string.IsNullOrEmpty(winner.Trim()))
                    throw new ArgumentException("Winner name should not be empty.");
                if (currentMatch.Teams.FirstOrDefault(x => x.Name.Equals(winner, StringComparison.InvariantCultureIgnoreCase)) == null)
                    throw new ArgumentException("Selected team name is not a valid one.");

                var winnerTeam = currentMatch.Teams.First(x => x.Name.Equals(winner, StringComparison.InvariantCultureIgnoreCase));
                var looserTeam = currentMatch.Teams.First(x => !x.Name.Equals(winner, StringComparison.InvariantCultureIgnoreCase));

                winnerTeam.IsWinner = true;
                looserTeam.IsWinner = false;

                if (currentMatch.HasPrevilageToGoFinal)
                    GetFinalBucket().AddTeam(winnerTeam);

                if (currentMatch.HasAnotherChance)
                {
                    if (!currentMatch.HasPrevilageToGoFinal)
                    {
                        CreateIntermediateMatch(currentMatch, winnerTeam);
                    }
                    CreateIntermediateMatch(currentMatch, looserTeam);                    
                }
                else if (!currentMatch.HasAnotherChance && !currentMatch.HasPrevilageToGoFinal)//&& currentMatch.Teams.Count == 2)
                {
                    if (!IsLastMatch(currentMatch))
                        CreateIntermediateMatch(currentMatch, winnerTeam);
                    else
                    {
                        var interM = GetIntermediateBuket(IsFirstMatch(currentMatch), currentMatch.BucketPlayOrder);
                        if (interM != null)
                        {
                            interM.AddTeam(winnerTeam);
                        }
                        else
                        {
                            GetFinalBucket().AddTeam(winnerTeam);
                        }
                    }
                }
                currentMatch.IsMatchPlayed = true;
                currentMatch = GetBucketToRun();
            } while (currentMatch != null);

            currentMatch = TournamentBuckets.First(x => x.BucketType == TournamentEnums.BucketType.Final);
            SendMessage(string.Format("Current Final Match -> {0} v/s {1}. Whom do you think won?", currentMatch.Teams.First().Name, currentMatch.Teams.Last().Name));
            var finalWinner = MatchWinnerSelector(currentMatch);
            var finalWinnerTeam = currentMatch.Teams.First(x => x.Name.Equals(finalWinner, StringComparison.InvariantCultureIgnoreCase));
            var finallooserTeam = currentMatch.Teams.First(x => !x.Name.Equals(finalWinner, StringComparison.InvariantCultureIgnoreCase));
            SendMessage(string.Format("The IPL champion is {0} and runnerup is {1}", finalWinnerTeam.Name, finallooserTeam.Name));
            currentMatch.IsMatchPlayed = true;
            finalWinnerTeam.IsWinner = true;
            finalWinnerTeam.IsWinner = false;
        }

        private void CreateIntermediateMatch(Bucket currentMatch, Team team)
        {
            //var otherBuckets = TournamentBuckets.Where(x => x.BucketPlayOrder != currentMatch.BucketPlayOrder && x.BucketType == TournamentEnums.BucketType.Qualifier)
            //    .OrderBy(x => x.BucketPlayOrder);

            var otherBuckets = TournamentBuckets.Where(x => x.BucketPlayOrder > currentMatch.BucketPlayOrder && x.BucketType == TournamentEnums.BucketType.Qualifier)
                .OrderBy(x => x.BucketPlayOrder);
            foreach (var item in otherBuckets)
            {
                item.BucketPlayOrder += 1;
            }
            var interMediateBucket = new Bucket(string.Format("Intermediate bucket {0}", currentMatch.BucketPlayOrder), false, TournamentEnums.BucketType.Qualifier, currentMatch.BucketPlayOrder + 1, false);
            interMediateBucket.AddTeam(team);
            TournamentBuckets.Add(interMediateBucket);
        }

        private bool CanGotoIntermediateStage(Bucket bucket)
        {
            return (bucket.HasAnotherChance || (!bucket.HasAnotherChance || !bucket.HasPrevilageToGoFinal));
        }

        private Bucket GetFinalBucket()
        {
            if (_finalBucket == null)
                _finalBucket = TournamentBuckets.First(x => x.BucketType == TournamentEnums.BucketType.Final);
            return _finalBucket;
        }

        private Bucket GetIntermediateBuket(bool isForward, int playOrder)
        {
            if (isForward)
                playOrder += 1;
            else
                playOrder -= 1;

            var intr = TournamentBuckets.FirstOrDefault(x => x.BucketPlayOrder == playOrder && !x.IsMatchPlayed && x.BucketType != TournamentEnums.BucketType.Final);

            if (intr != null)
                return intr;

            if (playOrder <= 0 || playOrder >= GetMaxMatchNumber())
                return null;            

            return GetIntermediateBuket(isForward, playOrder);
        }

        private int GetMaxMatchNumber()
        {
            return TournamentBuckets.Where(x => x.BucketType != TournamentEnums.BucketType.Final && !x.IsMatchPlayed).Max(x => x.BucketPlayOrder);
        }

        private bool IsLastMatch(Bucket bucket)
        {
            return bucket.BucketPlayOrder == GetMaxMatchNumber();
        }

        private bool IsFirstMatch(Bucket bucket)
        {
            var minOrder = TournamentBuckets.Where(x => x.BucketType != TournamentEnums.BucketType.Final && !x.IsMatchPlayed).Min(x => x.BucketPlayOrder);
            return bucket.BucketPlayOrder == minOrder;
        }

        private void ManageDefaultData()
        {
            if (MatchWinnerSelector == null)
            {
                MatchWinnerSelector = (bucket) =>
                {
                    var winner = new Random().Next(1, 10) % 2 == 0 ? bucket.Teams.First().Name : bucket.Teams.Last().Name;
                    SendMessage(string.Format("Winner is {0}", winner));
                    return winner;
                };
            }
            

            if (TournamentBuckets == null || TournamentBuckets.Count == 0)
            {
                TournamentBuckets.Add(new Bucket("Qualifier 1", true, TournamentEnums.BucketType.Qualifier, 1, true));
                TournamentBuckets.Add(new Bucket("Qualifier 2", false, TournamentEnums.BucketType.Qualifier, 2, false));
                TournamentBuckets.Add(new Bucket("Final", false, TournamentEnums.BucketType.Final, int.MaxValue, false));

                TournamentBuckets.ForEach(x =>
                {
                    if (x.BucketType != TournamentEnums.BucketType.Final)
                    {
                        x.Teams.Clear();
                        if (x.BucketPlayOrder == 1)
                        {
                            x.AddTeam(new Team("CSK"));
                            x.AddTeam(new Team("SRH"));
                        }
                        else if (x.BucketPlayOrder == 2)
                        {
                            x.AddTeam(new Team("KKR"));
                            x.AddTeam(new Team("RR"));
                        }

                    }
                });
            }
            else
            {
                TournamentBuckets.Add(new Bucket("Final", false, TournamentEnums.BucketType.Final, int.MaxValue, false));
            }
        }

        private void SendMessage(string message)
        {
            if (RecieveMessage != null)
                RecieveMessage(this, new MessageEventArguments(message));
        }

        private Bucket GetBucketToRun()
        {
            var bucket = TournamentBuckets.FirstOrDefault(x => x.BucketType == TournamentEnums.BucketType.Qualifier
                && !x.IsMatchPlayed);//&& x.Teams.Count == 2);
            return bucket;
        }
    }
}
