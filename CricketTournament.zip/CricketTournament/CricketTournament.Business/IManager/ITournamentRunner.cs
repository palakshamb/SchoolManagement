﻿using CricketTournament.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CricketTournament.Business.IManager
{
    /// <summary>
    /// Tournament runner
    /// </summary>
    public interface ITournamentRunner
    {
        /// <summary>
        /// Event handler to recieve messages from Tournament runner
        /// </summary>
        event EventHandler<MessageEventArguments> RecieveMessage;
        /// <summary>
        /// A func delegate to select match winner from the bucket. Pass null for random selection
        /// </summary>
        Func<Bucket, string> MatchWinnerSelector { get; set; }
        /// <summary>
        /// List of buckets in the tournament. Pass null for default IPL Playoff buckets.
        /// </summary>
        List<Bucket> TournamentBuckets { get; set; }
        /// <summary>
        /// Run the Tournament
        /// </summary>
        void RunTournament();
    }
}
