﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CricketTournament.Business
{
    public class MessageEventArguments : EventArgs
    {
        public string Message { get; set; }
        public MessageEventArguments(string message)
        {
            this.Message = message;
        }
    }
}
