﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CricketTournament.Model
{
    public class TeamEventArguments : EventArgs
    {
        public bool TeamStats { get; set; }
        public TeamEventArguments(bool status)
        {
            this.TeamStats = status;
        }
    }
}
