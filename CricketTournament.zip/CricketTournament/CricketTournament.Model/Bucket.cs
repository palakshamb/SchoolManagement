﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CricketTournament.Model;

namespace CricketTournament.Model
{
    public class Bucket
    {
        private List<Team> _teams;
        private bool _isMatchPlayed = false;
        public string Name { get; set; }
        public bool HasAnotherChance { get; set; }
        public TournamentEnums.BucketType BucketType { get; set; }
        public List<Team> Teams
        {
            get
            {
                return _teams;
            }
        }
        public int BucketPlayOrder { get; set; }
        public bool IsMatchPlayed { get { return _isMatchPlayed; } set { _isMatchPlayed = value; } }
        public bool HasPrevilageToGoFinal { get; set; }

        public void AddTeam(Team newTeam)
        {
            if (_teams.Count == 2)
                throw new ArgumentException("Bucket cannot have more than 2 teams.");
            newTeam.CurrentBucket = this;
            _teams.Add(newTeam);
        }

        public Bucket(string name, bool hasAnotherChance, TournamentEnums.BucketType bucketType, int bucketPlayOrder, bool hasPrevilageToGoFinal)
        {
            if (_teams == null)
            {
                _teams = new List<Team>();
            }

            this.Name = name;
            this.HasAnotherChance = hasAnotherChance;
            this.BucketType = bucketType;
            this.BucketPlayOrder = bucketPlayOrder;
            this.HasPrevilageToGoFinal = hasPrevilageToGoFinal;
        }
    }
}
