﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CricketTournament.Model
{
    public class Team
    {
        private bool? _isWinner = false;

        public delegate void TeamStatus(object obj, TeamEventArguments e);
        public event TeamStatus StatusChanged;

        public string Name { get; set; }
        public bool? IsWinner
        {
            get { return _isWinner; }
            set {
                if (_isWinner != value)
                {
                    if (StatusChanged != null)
                    {
                        StatusChanged(this, new TeamEventArguments((bool)value));
                    }
                }
            }
        }
        public Bucket CurrentBucket { get; set; }

        public Team(string name)
        {
            this.Name = name;
        }
    }
}
