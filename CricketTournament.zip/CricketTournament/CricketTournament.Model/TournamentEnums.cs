﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CricketTournament.Model
{
    public class TournamentEnums
    {
        public enum BucketType
        { 
            Qualifier = 0,
            SemiFinal,
            Final
        }
    }
}
